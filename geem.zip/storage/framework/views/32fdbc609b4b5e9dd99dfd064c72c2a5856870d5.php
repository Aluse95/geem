
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH D:\xampp\htdocs\geem\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>