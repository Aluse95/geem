<h1>Forget Password Email:</h1>
   
You can reset password from bellow link:
<button>
  <a href="{{ route('reset.password.get', $token) }}">Reset Password</a>
</button>